<?php











?>

<fieldset>
    <legend><b>PROFILE</b></legend>
	<form>
		<br/>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td>Bob</td>
				<td rowspan="7" align="center">
					<img width="128" src="../image/user.png"/>
                    <br/>
                    <a href="../write/picture.html">Change</a>
				</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>bob@aiub.edu</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td>Male</td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Date of Birth</td>
				<td>:</td>
				<td>19/09/1998</td>
			</tr>
		</table>	
        <hr/>
        <a href="../write/edit_profile.html">Edit Profile</a>	
		<input type="submit" value="Submit" >
		<br><a href="profile.php">Profile</a></br>
		<br><a href="profile.php">login</a></br>
		<br><a href="profile.php">password</a></br>
		<br><a href="profile.php">picture</a></br>
	</form>
</fieldset>