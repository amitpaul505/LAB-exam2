<html>

<fieldset>
<?php

$_user=[$login='POST']

?>
    <legend><b>LOGIN</b></legend>
    <form>
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text" action="reqired"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox" action="remember">Remember Me
		
		<br/><br/>
       /*  <input type="submit" value="Submit" */ <a href="profile.php">submit</a>
	   <input type="submit" value="Submit" >
		<br><a href="profile.php">Profile</a></br>
		<br><a href="profile.php">login</a></br>
		<br><a href="profile.php">password</a></br>
		<br><a href="profile.php">picture</a></br>
		
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>
