	<?php session_start();
//$user =$session[username];
if ($username){
	
	
	
	
		
	}
	else
	echo " <form action='changepassword.php' method= 'post'
Old password:<input type ='text' name='oldpassword' ><p>
repeat new passwordnew password:<input type ='password' name='repeatnewpassword' ><br>
<input type='submit' name='submit' value='change password' >

</form>
	
	";
	
/* else die(you must be logged in to change password); */	?>
		
	
	 
	 
	 
	 
