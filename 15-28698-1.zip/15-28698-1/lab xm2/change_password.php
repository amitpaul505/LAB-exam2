	<?php session_start();
//$user =$session[username];
if ($username){
	
	
	
	
		
	}
	else
	echo " <form action='changepassword.php' method= 'post'
Old password:<input type ='text' name='oldpassword' ><p>
repeat new passwordnew password:<input type ='password' name='repeatnewpassword' ><br>


</form>
	
	";
	
/* else die(you must be logged in to change password); */	?>




<fieldset>
    <legend><b>CHANGE PASSWORD</b></legend>
    <form>
        <table>
            <tr>
                <td><font size="3">Current Password</font></td>
				<td>:</td>
                <td><input type="password" /></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="green">New Password</font></td>
				<td>:</td>
                <td><input type="password" /></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="red">Retype New Password</font></td>
				
				<td>:</td>
                <td><input type="password" /></td>
                <td></td>
            </tr>
        </table>
        <hr />
       <input type='submit' name='submit' value='change password' >
    </form>
</fieldset>