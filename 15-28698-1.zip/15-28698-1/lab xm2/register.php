<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form method="post" action="register.php">
  	<?php include('errors.php'); ?>
	<br/>    <fieldset>
		<table width="100%" cellpadding="0" cellspacing="0">
			<td></td>
			</tr>
		<td></td>	</fieldset>
		
		<fieldset>
  	<div class="input-group">
  	  <label>name</label>
  	  <input type="text" name="username" value="<?php echo $username; ?>">
  	</div>
	 <td> </tr><td></td></fieldset>
	 
	 <fieldset>
	<div class="input-group">
  	  <label>id</label>
  	  <input type="number_format" name="id" value="<?php  ?>">
  	</div>
	 </tr>
	<tr></fieldset>
           <fieldset>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="<?php echo $email; ?>">
  	</div>
	</fieldset>
	 </tr> <tr><fieldset>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
	 </tr> <tr>
	 
	 </fieldset>
	 <fieldset>
  	<div class="input-group">
	
	
	
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div> </tr> <tr></fieldset>
  	<div class="input-group">
	
	
	<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio">Male
						<input name="gender" type="radio">Female
						<input name="gender" type="radio">Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2" />/
						<input type="text" size="2" />/
						<input type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
	
	
	
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div> </tr>
  	<p>
  	</p>
  </form>
  <fieldset>
  		Already a member? <a href="login.php">Sign in</a>
		</fieldset>
</body>
</html>